import {json,parse,string,sha256} from './_common.js';
// Reviews live in Cloudflare D1 (binding: DB). They go live immediately; spam is limited by validation, a no-links rule and 3 reviews per hour per visitor.
const PRODUCTS=['niacinamide-10-zinc-1','hyaluronic-acid-2-b5','multi-peptide-copper','multi-peptide-ha','salicylic-acid-2','caffeine-egcg-5','matrixyl-10-ha','azelaic-acid-10','ascorbyl-glucoside-12'];
const SKINS=['Combination Skin','Oily Skin','Dry Skin','Sensitive Skin','Normal Skin'];
const PHOTOS=['assets/ordinary_peach_box.jpg','assets/ordinary_shadows_stone.jpg','assets/ordinary_crystals.jpg','assets/ordinary_bathroom.jpg','assets/ordinary_linen.jpg'];
const LINK=/(https?:\/\/|www\.|\.com\b|\.pk\b|\.net\b|@\w+\.\w+)/i;
const clean=v=>String(v).replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim();
const shape=r=>({id:r.id,name:r.name,initials:(r.name.split(/\s+/).map(n=>n[0]).join('').toUpperCase().slice(0,2))||'RV',ratingNum:r.rating,rating:r.rating+'/5',text:r.text,age:String(r.age),texture:r.texture,skin:r.skin,photo:r.photo,createdAt:r.created_at});
const nodb=()=>json({ok:false,error:'Reviews are not available right now.'},503);

export async function onRequestGet({request,env}){
 if(!env.DB)return nodb();
 const product=new URL(request.url).searchParams.get('product');
 if(!PRODUCTS.includes(product))return json({ok:false,error:'Unknown product.'},400);
 try{
  const {results}=await env.DB.prepare('SELECT id,name,rating,text,age,texture,skin,photo,created_at FROM (SELECT * FROM reviews WHERE product=?1 ORDER BY created_at DESC LIMIT 60) ORDER BY created_at ASC').bind(product).all();
  return json({ok:true,reviews:results.map(shape)});
 }catch{return json({ok:false,error:'Could not load reviews.'},500);}
}

export async function onRequestPost({request,env}){
 if(!env.DB)return nodb();
 const r=await parse(request);if(r.error)return json({ok:false,error:r.error},r.status);
 const d=r.data;
 const name=typeof d.name==='string'?clean(d.name):'',text=typeof d.text==='string'?clean(d.text):'',texture=typeof d.texture==='string'?clean(d.texture):'';
 const rating=d.ratingNum,age=Number(d.age);
 if(!PRODUCTS.includes(d.product)||!string(name,40)||!string(text,400)||!string(texture,40)||!Number.isInteger(rating)||rating<1||rating>5||!Number.isInteger(age)||age<13||age>99||!SKINS.includes(d.skin)||!PHOTOS.includes(d.photo))
  return json({ok:false,error:'Please fill in every field correctly.'},400);
 if(LINK.test(name+' '+text+' '+texture))return json({ok:false,error:'Links are not allowed in reviews.'},400);
 try{
  const ipHash=await sha256((request.headers.get('CF-Connecting-IP')||'unknown')+'|ordinary-reviews');
  const since=new Date(Date.now()-3600*1000).toISOString();
  const recent=await env.DB.prepare('SELECT COUNT(*) AS n FROM reviews WHERE ip_hash=?1 AND created_at>?2').bind(ipHash,since).first();
  if(recent&&recent.n>=3)return json({ok:false,error:'You have posted a few reviews already. Please try again later.'},429);
  const id='r'+crypto.randomUUID().replace(/-/g,'').slice(0,16),token=crypto.randomUUID(),created=new Date().toISOString();
  await env.DB.prepare('INSERT INTO reviews (id,product,created_at,name,rating,text,age,texture,skin,photo,token_hash,ip_hash) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12)')
   .bind(id,d.product,created,name,rating,text,age,texture,d.skin,d.photo,await sha256(token),ipHash).run();
  return json({ok:true,token,review:shape({id,name,rating,text,age,texture,skin:d.skin,photo:d.photo,created_at:created})});
 }catch{return json({ok:false,error:'Could not save your review. Please try again.'},500);}
}

// A visitor can remove only their own review: the browser keeps the secret token that was returned when it was posted.
export async function onRequestDelete({request,env}){
 if(!env.DB)return nodb();
 let d;try{d=await request.json();}catch{return json({ok:false,error:'Invalid JSON'},400);}
 if(!d||typeof d.id!=='string'||typeof d.token!=='string')return json({ok:false,error:'Invalid request'},400);
 try{
  const res=await env.DB.prepare('DELETE FROM reviews WHERE id=?1 AND token_hash=?2').bind(d.id,await sha256(d.token)).run();
  return (res.meta&&res.meta.changes>0)?json({ok:true}):json({ok:false,error:'Review not found.'},404);
 }catch{return json({ok:false,error:'Could not remove the review.'},500);}
}
