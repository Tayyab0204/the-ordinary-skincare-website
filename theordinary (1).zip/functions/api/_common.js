// Cloudflare Pages Functions. Configure ORDERS_WEBHOOK_URL, CONTACT_WEBHOOK_URL,
// SUBSCRIBE_WEBHOOK_URL in Cloudflare dashboard environment variables (not browser JS).
export const json = (obj, status = 200) => new Response(JSON.stringify(obj), {status, headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export async function parse(request) {
  if (request.method !== 'POST') return {error:'Method not allowed',status:405};
  if (!(request.headers.get('content-type') || '').includes('application/json')) return {error:'Expected JSON',status:415};
  if (Number(request.headers.get('content-length') || 0) > 16000) return {error:'Request too large',status:413};
  try { const data = await request.json(); return data && typeof data === 'object' && !Array.isArray(data) ? {data} : {error:'Invalid request',status:400}; }
  catch { return {error:'Invalid JSON',status:400}; }
}
export const string = (x,max=240) => typeof x === 'string' && x.trim().length > 0 && x.trim().length <= max;
export async function forward(env, name, payload) {
  const endpoint = env[name];
  if (!endpoint) return {error:'This service is not configured yet. Nothing was submitted.',status:503};
  let url; try { url = new URL(endpoint); } catch { return {error:'Service endpoint configuration is invalid.',status:503}; }
  if (url.protocol !== 'https:') return {error:'Secure service endpoint is required.',status:503};
  try { const res = await fetch(url.toString(), {method:'POST',headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload),redirect:'error'});
    if(!res.ok) return {error:'Delivery service did not accept the submission. Please retry.',status:502};
    return {};
  } catch { return {error:'Delivery service unavailable. Please retry.',status:502}; }
}

// ---- helpers added for D1 orders / reviews / email ----
export async function sha256(text){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');}
export const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// Sends an email through Resend. Never throws: an email problem must not lose an order that is already saved.
export async function sendEmail(env,{to,subject,html,replyTo}){
  if(!env.RESEND_API_KEY||!to)return {skipped:true};
  try{
    const res=await fetch('https://api.resend.com/emails',{method:'POST',headers:{'Authorization':'Bearer '+env.RESEND_API_KEY,'Content-Type':'application/json'},
      body:JSON.stringify({from:env.EMAIL_FROM||'The Ordinary Store <onboarding@resend.dev>',to:[to],subject,html,...(replyTo?{reply_to:replyTo}:{})})});
    return res.ok?{ok:true}:{error:'email '+res.status};
  }catch{return {error:'email failed'};}
}
