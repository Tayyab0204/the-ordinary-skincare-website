import {json,parse,string,forward,esc,sendEmail} from './_common.js';
const PRODUCTS = {"niacinamide-10-zinc-1": {"price": 3400, "sale": null, "percentOff": true, "variants": {"30 ml": 3400, "60 ml": 5600}}, "hyaluronic-acid-2-b5": {"price": 2500, "sale": null, "percentOff": false, "variants": null}, "multi-peptide-copper": {"price": 8100, "sale": 7200, "percentOff": false, "variants": null}, "multi-peptide-ha": {"price": 5600, "sale": 5000, "percentOff": false, "variants": null}, "salicylic-acid-2": {"price": 2200, "sale": null, "percentOff": false, "variants": null}, "caffeine-egcg-5": {"price": 2200, "sale": null, "percentOff": false, "variants": null}, "matrixyl-10-ha": {"price": 3900, "sale": 3600, "percentOff": false, "variants": null}, "azelaic-acid-10": {"price": 3100, "sale": 2800, "percentOff": false, "variants": null}, "ascorbyl-glucoside-12": {"price": 3400, "sale": 3100, "percentOff": false, "variants": null}};
const NAMES={'niacinamide-10-zinc-1':'Niacinamide 10% + Zinc 1%','hyaluronic-acid-2-b5':'Hyaluronic Acid 2% + B5','multi-peptide-copper':'Multi-Peptide + Copper Peptides 1%','multi-peptide-ha':'Multi-Peptide + HA Serum','salicylic-acid-2':'Salicylic Acid 2% Solution','caffeine-egcg-5':'Caffeine Solution 5% + EGCG','matrixyl-10-ha':'Matrixyl 10% + HA','azelaic-acid-10':'Azelaic Acid Suspension 10%','ascorbyl-glucoside-12':'Ascorbyl Glucoside Solution 12%'};
const rs=n=>'Rs. '+Number(n).toLocaleString('en-US');
const money=n=>Math.round(n*100)/100;
// Keep in sync with CONFIG.offer in store.js (percent off for percentOff products, free serums per order, shipping rules).
const OFFER={enabled:true,percent:50,freeUnits:1},SHIPPING_FLAT=250,FREE_SHIPPING_OVER=5000;
export async function onRequestPost({request,env,waitUntil}) {
 const r=await parse(request);if(r.error)return json({ok:false,error:r.error},r.status);
 const d=r.data,c=d.customer||{};
 if(![c.name,c.email,c.phone,c.address,c.city].every(v=>string(v,254)) || !/^\S+@\S+\.\S+$/.test(c.email) || !/^03\d{9}$/.test(String(c.phone).replace(/[^\d+]/g,'').replace(/^\+?(00)?92/,'0')) || String(c.country).toLowerCase()!=='pakistan')return json({ok:false,error:'Please provide valid Pakistan delivery details.'},400);
 if(!Array.isArray(d.items)||!d.items.length||d.items.length>40||!d.items.every(i=>i&&PRODUCTS[i.sku]&&Number.isInteger(i.qty)&&i.qty>=1&&i.qty<=99))return json({ok:false,error:'Invalid products or quantities.'},400);
 const orderItems=[];let gross=0,subtotal=0;let cheapest=null;
 for(const item of d.items){const product=PRODUCTS[item.sku];const variants=product.variants;const size=item.size||'';
  if(variants && !(size in variants))return json({ok:false,error:'Invalid product size.'},400);
  const unit=variants?variants[size]:product.price;
  const paid=product.sale!=null?product.sale:(product.percentOff&&OFFER.enabled)?money(unit*(100-OFFER.percent)/100):unit;
  gross+=unit*item.qty;subtotal+=paid*item.qty;
  const record={sku:item.sku,size,qty:item.qty,unit,unit_paid:paid};orderItems.push(record);
  if(!cheapest||paid<cheapest.unit_paid)cheapest=record;
 }
 gross=money(gross);subtotal=money(subtotal);const shipping=subtotal>=FREE_SHIPPING_OVER?0:SHIPPING_FLAT;const total=money(subtotal+shipping);
 if(money(Number(d.total))!==total)return json({ok:false,error:'Your bag total changed. Refresh checkout and try again.'},409);
 const id='TO-'+crypto.randomUUID().slice(0,12).toUpperCase();
 const payload={type:'order',id,placed:new Date().toISOString(),customer:{name:c.name.trim(),email:c.email.trim(),phone:c.phone.trim(),address:c.address.trim(),city:c.city.trim(),postal:String(c.postal||'').slice(0,20),country:'Pakistan',note:String(c.note||'').slice(0,600)},payment:'cod',items:orderItems,free_items:(cheapest&&OFFER.enabled&&OFFER.freeUnits)?[{sku:cheapest.sku,size:cheapest.size,qty:OFFER.freeUnits}]:[],currency:'PKR',gross,discount:money(gross-subtotal),subtotal,shipping,total};
 // 1) Save the order in Cloudflare D1 (binding name: DB). Without D1 or a webhook nothing can be stored, so refuse honestly.
 if(!env.DB&&!env.ORDERS_WEBHOOK_URL)return json({ok:false,error:'This service is not configured yet. Nothing was submitted.'},503);
 if(env.DB){
  try{
   await env.DB.prepare('INSERT INTO orders (id,placed_at,name,email,phone,address,city,postal,note,items,free_items,gross,discount,subtotal,shipping,total,payment) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17)')
    .bind(id,payload.placed,payload.customer.name,payload.customer.email,payload.customer.phone,payload.customer.address,payload.customer.city,payload.customer.postal,payload.customer.note,JSON.stringify(orderItems),JSON.stringify(payload.free_items),gross,payload.discount,subtotal,shipping,total,'cod').run();
  }catch{return json({ok:false,error:'Could not save your order. Please try again.'},500);}
 }
 // 2) Optional extra copy to a webhook (Google Sheet / Make). If D1 already saved the order, a webhook problem is ignored.
 if(env.ORDERS_WEBHOOK_URL){const w=await forward(env,'ORDERS_WEBHOOK_URL',payload);if(w.error&&!env.DB)return json({ok:false,error:w.error},w.status);}
 // 3) Email the shop owner (ORDER_EMAIL_TO). The order is already saved, so an email problem never fails the order.
 const c2=payload.customer,rows=[...orderItems.map(i=>`<tr><td style="padding:6px 10px;border-bottom:1px solid #eee">${esc(NAMES[i.sku]||i.sku)}${i.size?' ('+esc(i.size)+')':''}</td><td style="padding:6px 10px;border-bottom:1px solid #eee">x ${i.qty}</td><td style="padding:6px 10px;border-bottom:1px solid #eee;text-align:right">${rs(i.unit_paid*i.qty)}</td></tr>`),
  ...payload.free_items.map(i=>`<tr><td style="padding:6px 10px;border-bottom:1px solid #eee">${esc(NAMES[i.sku]||i.sku)}${i.size?' ('+esc(i.size)+')':''} <b>(FREE)</b></td><td style="padding:6px 10px;border-bottom:1px solid #eee">x ${i.qty}</td><td style="padding:6px 10px;border-bottom:1px solid #eee;text-align:right">Rs. 0</td></tr>`)].join('');
 const html=`<div style="font-family:Arial,sans-serif;max-width:560px;color:#111"><h2 style="margin:0 0 4px">New order ${esc(id)}</h2><p style="margin:0 0 16px;color:#666">Cash on delivery &middot; ${esc(payload.placed)}</p>
  <table style="width:100%;border-collapse:collapse;font-size:14px">${rows}
  <tr><td colspan="2" style="padding:6px 10px">Subtotal</td><td style="padding:6px 10px;text-align:right">${rs(subtotal)}</td></tr>
  <tr><td colspan="2" style="padding:6px 10px">Delivery</td><td style="padding:6px 10px;text-align:right">${shipping?rs(shipping):'Free'}</td></tr>
  <tr><td colspan="2" style="padding:8px 10px;font-weight:bold">Total to collect</td><td style="padding:8px 10px;text-align:right;font-weight:bold">${rs(total)}</td></tr></table>
  <h3 style="margin:20px 0 6px">Customer</h3><p style="margin:0;font-size:14px;line-height:1.6">${esc(c2.name)}<br>${esc(c2.phone)}<br>${esc(c2.email)}<br>${esc(c2.address)}, ${esc(c2.city)} ${esc(c2.postal)}<br>${c2.note?'<i>Note: '+esc(c2.note)+'</i>':''}</p></div>`;
 const mail=sendEmail(env,{to:env.ORDER_EMAIL_TO,subject:`New order ${id} - ${rs(total)}`,html,replyTo:c2.email});
 // 4) Confirmation to the customer. Only sent once EMAIL_FROM is a verified domain in Resend (the Resend sandbox sender can only email the account owner).
 const custHtml=`<div style="font-family:Arial,sans-serif;max-width:560px;color:#111"><h2 style="margin:0 0 4px">Thank you, ${esc(c2.name.split(' ')[0])}.</h2><p style="margin:0 0 16px;color:#666">We received your order ${esc(id)}. Payment: cash on delivery.</p><table style="width:100%;border-collapse:collapse;font-size:14px">${rows}<tr><td colspan="2" style="padding:6px 10px">Delivery</td><td style="padding:6px 10px;text-align:right">${shipping?rs(shipping):'Free'}</td></tr><tr><td colspan="2" style="padding:8px 10px;font-weight:bold">Total to pay on delivery</td><td style="padding:8px 10px;text-align:right;font-weight:bold">${rs(total)}</td></tr></table><p style="font-size:14px;line-height:1.6">Delivering to: ${esc(c2.address)}, ${esc(c2.city)}.<br>We will contact you on ${esc(c2.phone)} to confirm delivery (usually 3&ndash;5 business days).</p></div>`;
 const custMail=env.EMAIL_FROM?sendEmail(env,{to:c2.email,subject:`Your order ${id} is confirmed`,html:custHtml,replyTo:env.ORDER_EMAIL_TO}):Promise.resolve();
 if(waitUntil){waitUntil(mail);waitUntil(custMail);}else{await mail;await custMail;}
 return json({ok:true,orderId:id,total});
}
