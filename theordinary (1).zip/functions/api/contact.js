import {json,parse,string,forward,esc,sendEmail} from './_common.js';
// Saves the message in D1 (binding DB, table `messages`), emails it to ORDER_EMAIL_TO, and optionally forwards to CONTACT_WEBHOOK_URL.
export async function onRequestPost({request,env,waitUntil}) {
 const r=await parse(request);if(r.error)return json({ok:false,error:r.error},r.status);
 const d=r.data;if(!string(d.name,120)||!string(d.email,254)||!/^\S+@\S+\.\S+$/.test(d.email)||!string(d.message,5000))return json({ok:false,error:'Please complete valid name, email and message fields.'},400);
 if(typeof d.website==='string'&&d.website.trim())return json({ok:true}); // honeypot: real visitors never fill this hidden field
 const payload={type:'contact',name:d.name.trim(),email:d.email.trim(),topic:typeof d.topic==='string'?d.topic.slice(0,120):'',message:d.message.trim(),receivedAt:new Date().toISOString()};
 if(!env.DB&&!env.CONTACT_WEBHOOK_URL&&!(env.RESEND_API_KEY&&env.ORDER_EMAIL_TO))return json({ok:false,error:'This service is not configured yet. Nothing was submitted.'},503);
 let saved=false;
 if(env.DB){try{await env.DB.prepare('INSERT INTO messages (id,received_at,name,email,topic,message) VALUES (?1,?2,?3,?4,?5,?6)').bind('m'+crypto.randomUUID().replace(/-/g,'').slice(0,16),payload.receivedAt,payload.name,payload.email,payload.topic,payload.message).run();saved=true;}catch{}}
 if(env.CONTACT_WEBHOOK_URL){const w=await forward(env,'CONTACT_WEBHOOK_URL',payload);if(!w.error)saved=true;}
 const html=`<div style="font-family:Arial,sans-serif;max-width:560px;color:#111"><h2 style="margin:0 0 8px">New message from ${esc(payload.name)}</h2><p style="margin:0 0 4px;color:#666">${esc(payload.email)}${payload.topic?' &middot; '+esc(payload.topic):''}</p><p style="font-size:14px;line-height:1.6;white-space:pre-wrap">${esc(payload.message)}</p></div>`;
 const mail=sendEmail(env,{to:env.ORDER_EMAIL_TO,subject:`Contact: ${payload.topic||'message'} from ${payload.name}`,html,replyTo:payload.email});
 const sent=await mail; // wait so we know whether at least one copy was delivered
 if(!saved&&!(sent&&sent.ok))return json({ok:false,error:'Could not deliver your message. Please try again.'},502);
 return json({ok:true});
}
