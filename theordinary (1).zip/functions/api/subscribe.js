import {json,parse,forward} from './_common.js';
// Saves the address in D1 (binding DB, table `subscribers`; duplicates are ignored) and optionally forwards to SUBSCRIBE_WEBHOOK_URL.
export async function onRequestPost({request,env}) {
 const r=await parse(request);if(r.error)return json({ok:false,error:r.error},r.status);
 const email=r.data.email;if(typeof email!=='string'||email.length>254||!/^\S+@\S+\.\S+$/.test(email))return json({ok:false,error:'Enter a valid email address.'},400);
 if(!env.DB&&!env.SUBSCRIBE_WEBHOOK_URL)return json({ok:false,error:'This service is not configured yet. Nothing was submitted.'},503);
 const clean=email.trim().toLowerCase(),at=new Date().toISOString();
 let saved=false;
 if(env.DB){try{await env.DB.prepare('INSERT OR IGNORE INTO subscribers (email,subscribed_at) VALUES (?1,?2)').bind(clean,at).run();saved=true;}catch{}}
 if(env.SUBSCRIBE_WEBHOOK_URL){const w=await forward(env,'SUBSCRIBE_WEBHOOK_URL',{type:'subscribe',email:clean,receivedAt:at});if(!w.error)saved=true;}
 return saved?json({ok:true}):json({ok:false,error:'Subscription is temporarily unavailable.'},502);
}
